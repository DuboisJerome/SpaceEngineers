﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRage;
using VRageMath;

namespace IngameScript
{
	partial class Program
	{
		public class AutomaticMiningSystem
		{
			// references to blocks
			private List<IMyShipDrill> listDrills = new List<IMyShipDrill>();
			// Pistons in mining direction
			private List<IMyPistonBase> listPistonMDir = new List<IMyPistonBase>();
			// Pistons in mining opposite direction
			private List<IMyPistonBase> listPistonMODir = new List<IMyPistonBase>();
			private List<IMyLightingBlock> listLight = new List<IMyLightingBlock>();
			private List<IMyCargoContainer> listCargo = new List<IMyCargoContainer>();
			private IMyBeacon beacon = null;
			private IMyMotorStator mainMotor = null;

			// var
			private double lastAngle;
			private int currentPhase;
			private bool isRunning;
			private AutomaticMiningSystemParams _params;
			private Logger logger;

			public AutomaticMiningSystem(AutomaticMiningSystemParams parameters, Program program)
			{
				this._params = parameters;
				this.lastAngle = _params.MinRotorAngle;
				this.currentPhase = PHASE_NONE;
				this.isRunning = false;
				this.logger = program.logger;
			}

			public void Start()
			{
				logger.Info("==> Start");
				// If off, start from the beginning = launch
				// else continue the current task
				if (currentPhase == PHASE_NONE)
				{
					currentPhase = PHASE_LAUNCH;
				}
				else
				{
					SetDrillsOnOff(true);
				}
				SetBeaconAlert(false);

				isRunning = true;
			}

			public void Stop()
			{
				logger.Info("==> Stop");
				// Turn off drills
				SetDrillsOnOff(false);
				// Stop pistons
				foreach (IMyPistonBase p in listPistonMDir)
				{
					p.SetValue("Velocity", 0F);
				}
				foreach (IMyPistonBase p in listPistonMODir)
				{
					p.SetValue("Velocity", 0F);
				}
				if (mainMotor != null)
				{
					mainMotor.SetValue("Velocity", 0F);
				}

				isRunning = false;
			}

			public void Reset()
			{
				logger.Info("==> Reset");
				currentPhase = PHASE_ENDING;
				SetBeaconAlert(false);

				isRunning = true;
			}

			public void AutoUpdate()
			{
				if (!isRunning)
				{
					return;
				}

				bool isMustTestCargoCapacity = currentPhase != PHASE_ENDING && currentPhase != PHASE_NONE;
				if (isMustTestCargoCapacity && IsAllCargoFull())
				{
					AlertCargoFull();
				}
				else
				{
					bool isPhaseEnded = false;
					if (currentPhase == PHASE_LAUNCH)
					{
						SetLightRunning();
						logger.Info("PHASE_LAUNCH");
						isPhaseEnded = Init();
					}
					else if (currentPhase == PHASE_EXTENDING_DRILL)
					{
						SetLightRunning();
						logger.Info("PHASE_EXTENDING_DRILL");
						isPhaseEnded = RunPhaseExtendingPistonMiningDirection();
					}
					else if (currentPhase == PHASE_RETRACTING_LG)
					{
						SetLightRunning();
						logger.Info("PHASE_RETRACTING_LG");
						isPhaseEnded = RunPhaseRetractingPistionOppositeMiningDirection();
					}
					else if (currentPhase == PHASE_MOVING_MOTOR)
					{
						SetLightRunning();
						logger.Info("PHASE_MOVING_MOTOR");
						isPhaseEnded = RunPhaseRotating();
					}
					else if (currentPhase == PHASE_ENDING)
					{
						logger.Info("PHASE_ENDING");
						isPhaseEnded = End();
					}
					else
					{
						isRunning = false;
					}

					if (isPhaseEnded)
					{
						GoToNextPhase();
					}
				}
			}

			private void GoToNextPhase()
			{
				switch (currentPhase)
				{
					case PHASE_LAUNCH: currentPhase = PHASE_EXTENDING_DRILL; break;
					case PHASE_EXTENDING_DRILL: currentPhase = PHASE_RETRACTING_LG; break;
					case PHASE_RETRACTING_LG: currentPhase = PHASE_MOVING_MOTOR; break;
					case PHASE_MOVING_MOTOR: currentPhase = PHASE_ENDING; break;
					default:
						currentPhase = PHASE_NONE;
						break;
				}
			}

			private void AlertCargoFull()
			{
				logger.Info("Alert cargo full");
				SetLightFull();
				SetBeaconAlert(true, _params.Name + " is Full");
				Stop();
			}

			private void SetLightFinnish()
			{
				foreach (IMyLightingBlock light in listLight)
				{
					light.SetValue("Color", Color.Green);
					light.SetValue("OnOff", true);
					light.SetValue("Blink Interval", 0F);
					light.SetValue("Blink Lenght", 50F);
				}
			}

			private void SetLightRunning()
			{
				foreach (IMyLightingBlock light in listLight)
				{
					light.SetValue("Color", Color.Blue);
					light.SetValue("OnOff", true);
					light.SetValue("Blink Interval", 1F);
					light.SetValue("Blink Lenght", 20F);
				}
			}

			private void SetLightFull()
			{
				foreach (IMyLightingBlock light in listLight)
				{
					light.SetValue("Color", Color.Orange);
					light.SetValue("OnOff", true);
					light.SetValue("Blink Interval", 1F);
					light.SetValue("Blink Lenght", 50F);
				}
			}

			private void SetBeaconAlert(bool isAlert, string newBeaconName = null)
			{
				if (beacon != null)
				{
					beacon.SetValue("Radius", isAlert ? _params.MaxBeaconRadius : _params.MinBeaconRadius);
					beacon.HudText = (isAlert && newBeaconName != null) ? newBeaconName : _params.Name;

				}
			}

			private bool IsAllCargoFull()
			{
				foreach (IMyCargoContainer cargo in listCargo)
				{
					IMyInventory inventory = cargo.GetInventory();
					if (inventory.CurrentVolume != inventory.MaxVolume)
					{
						return false;
					}
				}
				return true;
			}

			public void LoadBlocks(Program program)
			{
				listDrills = new List<IMyShipDrill>();
				program.GridTerminalSystem.GetBlocksOfType(listDrills);

				IMyBlockGroup groupPistonsMDir = program.GridTerminalSystem.GetBlockGroupWithName(_params.GrpNamePistonMDir);
				listPistonMDir = new List<IMyPistonBase>();
				if (groupPistonsMDir == null)
				{
					logger.Error("Group \"" + _params.GrpNamePistonMDir + "\" not found");
				}
				else
				{
					groupPistonsMDir.GetBlocksOfType(listPistonMDir);
				}

				IMyBlockGroup groupPistonMODir = program.GridTerminalSystem.GetBlockGroupWithName(_params.GrpNamePistonMODir);
				listPistonMODir = new List<IMyPistonBase>();
				if (groupPistonMODir == null)
				{
					logger.Info("Group \"" + _params.GrpNamePistonMODir + "\" not found");
				}
				else
				{
					program.GridTerminalSystem.GetBlocksOfType(listPistonMODir);
				}

				List<IMyBeacon> listBeacon = new List<IMyBeacon>();
				program.GridTerminalSystem.GetBlocksOfType(listBeacon);
				if (listBeacon.Count > 0)
				{
					beacon = listBeacon.First();
					beacon.SetValue("Radius", _params.MinBeaconRadius);
				}
				else
				{
					logger.Info("No beacon found");
				}

				mainMotor = program.GridTerminalSystem.GetBlockWithName(_params.MainRotorName) as IMyMotorStator;
				if (mainMotor == null)
				{
					logger.Info("No rotor \"" + _params.MainRotorName + "\" found");
				}
				else
				{
					mainMotor.SetValue("LowerLimit", _params.MinRotorAngle);
					mainMotor.SetValue("UpperLimit", _params.MinRotorAngle);
				}

				IMyBlockGroup groupLights = program.GridTerminalSystem.GetBlockGroupWithName(_params.GrpNameLight);
				listLight = new List<IMyLightingBlock>();
				if (groupLights == null)
				{
					logger.Info("Group \"" + _params.GrpNameLight + "\" not found");
				}
				else
				{
					groupLights.GetBlocksOfType(listLight);
				}

				IMyBlockGroup groupCargo = program.GridTerminalSystem.GetBlockGroupWithName(_params.GrpNameCargo);
				listCargo = new List<IMyCargoContainer>();
				if (groupCargo == null)
				{
					logger.Info("Group \"" + _params.GrpNameCargo + "\" not found");
				}
				else
				{
					groupCargo.GetBlocksOfType(listCargo);
				}
			}

			private void SetDrillsOnOff(bool isOn)
			{
				foreach (IMyShipDrill d in listDrills)
				{
					d.SetValue("OnOff", isOn);
				}
			}

			// Retract pistons
			private bool Init()
			{
				bool isInitEnd = true;
				isInitEnd &= InitPistonMiningDirection();
				isInitEnd &= InitPistonMiningOppositeDirection();
				return isInitEnd;
			}

			private bool InitPistonMiningDirection()
			{
				bool isInitEnd = true;
				foreach (IMyPistonBase p in listPistonMDir)
				{
					if (p.Status != PistonStatus.Retracted)
					{
						isInitEnd = false;
						// retracts
						p.SetValue("Velocity", -_params.FastPistonVelocity);
						// share inertia tensor
						p.SetValue("ShareInertiaTensor", true);
					}
				}

				SetDrillsOnOff(!isInitEnd);

				return isInitEnd;
			}

			private bool InitPistonMiningOppositeDirection()
			{
				bool isInitEnd = true;
				foreach (IMyPistonBase p in listPistonMODir)
				{
					if (p.Status != PistonStatus.Extended)
					{
						isInitEnd = false;
						// extends
						p.SetValue("Velocity", _params.FastPistonVelocity);
						// share inertia tensor
						p.SetValue("ShareInertiaTensor", true);
					}
				}
				return isInitEnd;
			}

			private bool RunPhaseExtendingPistonMiningDirection()
			{
				if (listPistonMDir == null || listPistonMDir.Count <= 0)
					return true;
				SetDrillsOnOff(true);
				// looking for extending piston
				IMyPistonBase currentPistonExtending = listPistonMDir.Find(p => p.Status == PistonStatus.Extending);

				if (currentPistonExtending != null)
				{
					// piston mining already extending
					// do nothing
					return false;
				}

				foreach (IMyPistonBase p in listPistonMDir)
				{
					if (p.Status != PistonStatus.Extended)
					{
						// Extend one of the pistons not already extended
						p.SetValue("Velocity", _params.SlowPistonVelocity);
						return false;
					}
				}

				return true;
			}

			private bool RunPhaseRetractingPistionOppositeMiningDirection()
			{
				if (listPistonMODir == null || listPistonMODir.Count <= 0)
					return true;
				SetDrillsOnOff(true);
				bool isAllPistonRetracted = true;

				foreach (IMyPistonBase p in listPistonMODir)
				{
					if (p.Status != PistonStatus.Retracting)
					{
						p.SetValue("Velocity", -_params.SlowPistonVelocity);
					}
					if (p.Status != PistonStatus.Retracted)
					{
						isAllPistonRetracted = false;
					}
				}

				return isAllPistonRetracted;
			}

			private bool RunPhaseRotating()
			{
				if (mainMotor == null)
					return true;
				bool isMiningEnd = false;
				bool isInitEnd = Init();
				if (isInitEnd)
				{
					double newUpperLimit = lastAngle + _params.StepRotorAngle;
					if (newUpperLimit > _params.MaxRotorAngle)
					{
						isMiningEnd = true;
					}
					else
					{
						double currentAngle = Math.Round(mainMotor.Angle * 180.0 / Math.PI);
						bool isEndRotating = currentAngle == newUpperLimit;
						if (isEndRotating)
						{
							// End rotation
							mainMotor.SetValue("Velocity", 0F);
							currentPhase = PHASE_EXTENDING_DRILL;
							lastAngle = currentAngle;
						}
						else
						{
							// Start rotation
							mainMotor.SetValue("UpperLimit", (float)newUpperLimit);
							mainMotor.SetValue("Velocity", _params.RotorVelocity);
						}
					}
				}

				return isMiningEnd;
			}

			private bool End()
			{
				bool isEnd = Init();
				if (isEnd)
				{
					if (mainMotor != null)
					{
						this.lastAngle = _params.MinRotorAngle;
						mainMotor.SetValue("UpperLimit", _params.MinRotorAngle);
						mainMotor.SetValue("Velocity", -_params.RotorVelocity);
					}
					SetLightFinnish();
					SetBeaconAlert(true, _params.Name + " has Finnished");
					SetDrillsOnOff(false);
				}
				return isEnd;
			}
		}

	}
}
