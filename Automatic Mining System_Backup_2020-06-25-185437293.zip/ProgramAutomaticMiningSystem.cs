﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRageMath;

namespace IngameScript
{
	partial class Program : MyGridProgram
	{
		// arg
		const string ARG_START = "Start";
		const string ARG_STOP = "Stop";
		const string ARG_RESET = "Reset";

		const int PHASE_NONE = 0;
		const int PHASE_LAUNCH = 1;
		const int PHASE_EXTENDING_DRILL = 2;
		const int PHASE_RETRACTING_LG = 3;
		const int PHASE_MOVING_MOTOR = 4;
		const int PHASE_ENDING = 5;

		Logger logger;
		AutomaticMiningSystem ads = null;

		public Program()
		{
			Runtime.UpdateFrequency = UpdateFrequency.Update100;

			logger = new Logger(this);
			
			AutomaticMiningSystemParams parameters = new AutomaticMiningSystemParams(this);
			if (Me.CustomData != string.Empty)
			{
				string[] customParams = Me.CustomData.Split('\n');
				if(customParams != null && customParams.Length > 0)
				{
					foreach (string customParam in customParams)
					{
						string[] splitParam = customParam.Split('=');
						if (splitParam == null || splitParam.Length < 2)
							continue;
						string propertyName = splitParam[0];
						string propertyValue = splitParam[1];
						parameters.SetProperty(propertyName, propertyValue);
					}
				}
			}
			ads = new AutomaticMiningSystem(parameters, this);
		}

		public void Main(string arg, UpdateType updateSource)
		{
			if (arg == ARG_START)
			{
				ads.LoadBlocks(this);
				ads.Start();
			}
			else if (arg == ARG_STOP)
			{
				ads.LoadBlocks(this);
				ads.Stop();
			}
			else if (arg == ARG_RESET)
			{
				logger.Clear();
				ads.LoadBlocks(this);
				ads.Reset();
			}
			else
			{
				if ((updateSource & (UpdateType.Update100)) != 0)
				{
					ads.AutoUpdate();
				}
			}
		}
	}
}